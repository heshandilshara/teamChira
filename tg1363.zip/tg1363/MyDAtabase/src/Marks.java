public class Marks {
    
}
