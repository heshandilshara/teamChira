import java.sql.*;

public class Database {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection myConnection= DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","1234");
            Statement stmt=myConnection.createStatement();
            ResultSet rs=stmt.executeQuery("select * from basicdata");
            while(rs.next()){
                System.out.println(rs.getString(1)+" "+ rs.getString(2)+" "+rs.getString(3));


            }
            myConnection.close();

        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
