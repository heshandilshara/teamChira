import java.sql.DriverManager;

public class MyBasicObTest {
    public static void main(String[] args) {
        Connection myCon = DriverManager.getConnection(jdbc:mysql://localhost:3306/tecruh","root",“123")
    }
}
